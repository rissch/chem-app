import pandas as pd
import sqlite3

# Load your CSV
csv_file = "ChEBI_lite_with_smiles.csv"
df = pd.read_csv(csv_file)

# Fill missing values if necessary
df = df.fillna("")

# Connect to (or create) a SQLite database
conn = sqlite3.connect("chemistry.db")

# Write the DataFrame to SQLite table named "compounds"
df.to_sql("compounds", conn, if_exists="replace", index=False)

# (Optional) Create an index on 'Formula' for faster search
with conn:
    conn.execute("CREATE INDEX IF NOT EXISTS idx_formula ON compounds (Formula)")

conn.close()

print("✅ CSV has been successfully converted to SQLite database.")
