import sqlite3
import pandas as pd

# Connect to the database
conn = sqlite3.connect("chemistry.db")
cursor = conn.cursor()

# Read the compounds table
df = pd.read_sql_query("SELECT rowid, Formula, SMILES FROM compounds", conn)

# Define classification function
def classify_compound(formula):
    if not formula:
        return "Unknown"
    formula = formula.upper()
    if "COOH" in formula:
        return "Carboxylic Acid"
    elif "OH" in formula and "COOH" not in formula:
        return "Alcohol"
    elif formula.startswith("H") and "C" not in formula:
        return "Acid"
    elif "NH2" in formula:
        return "Amine"
    elif any(metal in formula for metal in ["Na", "K", "Ca", "Mg", "Fe"]) and "Cl" in formula:
        return "Salt"
    elif "C" in formula and "H" in formula:
        return "Organic"
    else:
        return "Inorganic"

# Apply classification
df['Type'] = df['Formula'].apply(classify_compound)

# Check if 'Type' column exists, and add it if not
cursor.execute("PRAGMA table_info(compounds);")
columns = [col[1] for col in cursor.fetchall()]
if "Type" not in columns:
    cursor.execute("ALTER TABLE compounds ADD COLUMN Type TEXT;")

# Update the database with classifications
for _, row in df.iterrows():
    cursor.execute("UPDATE compounds SET Type = ? WHERE rowid = ?", (row['Type'], row['rowid']))

# Save and close
conn.commit()
conn.close()
