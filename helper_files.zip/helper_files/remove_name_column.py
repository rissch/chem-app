import pandas as pd

# Load data
df = pd.read_csv("ChEBI_lite_with_smiles.csv")

df = df.drop('Name', axis=1)

df.to_csv("ChEBI_lite_with_smiles.csv")