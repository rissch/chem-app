from rdkit import Chem
from rdkit.Chem import rdMolDescriptors
import pandas as pd

def sdf_to_csv_with_smiles(sdf_path, csv_path):
    supplier = Chem.SDMolSupplier(sdf_path)
    data = []

    for mol in supplier:
        if mol is None:
            continue

        entry = {}

        # Molecule name
        entry["Name"] = mol.GetProp('_Name') if mol.HasProp('_Name') else None

        # Molecular formula
        try:
            entry["Formula"] = rdMolDescriptors.CalcMolFormula(mol)
        except:
            entry["Formula"] = None

        # SMILES
        try:
            entry["SMILES"] = Chem.MolToSmiles(mol)
        except:
            entry["SMILES"] = None

        # Add all other properties
        for prop_name in mol.GetPropNames():
            entry[prop_name] = mol.GetProp(prop_name)

        data.append(entry)

    df = pd.DataFrame(data)
    df.to_csv(csv_path, index=False)
    print(f"Saved {len(df)} compounds to: {csv_path}")

# Example usage
sdf_to_csv_with_smiles("ChEBI_lite_3star.sdf", "ChEBI_lite_with_smiles.csv")
